#include "SQLiteDatabase.h"
#include <stdlib.h>
#include <assert.h>

SQLiteDatabase::SQLiteDatabase()
{
    //ctor
        dbName = "";
        db = NULL;
        pVm = NULL;
        result = NULL;
}

SQLiteDatabase::SQLiteDatabase(string filename)
{
    //ctor
    if(filename != "") Open(filename);

}

SQLiteDatabase::~SQLiteDatabase()
{
    //dtor
    sqlite3_free_table(result);
    QueryClose();
    Close();
    dbName = "";
}

bool SQLiteDatabase::Open(string filename)
{
    Close();
    dbName = filename;

    int rc;
    rc = sqlite3_open(filename.c_str(), &db);
    if (! db)
	{

		lastErr = GetErrorMessage(rc);
		return false;
	};

	return true;
}

bool SQLiteDatabase::Close()
{
    if (db)
	{
		sqlite3_close(db);
	 	db = NULL;
	}

	return true;
}

string SQLiteDatabase::SQLiteVersion()
{
    return sqlite3_libversion();
}

string SQLiteDatabase::GetErrorMessage(int errorCode)
{
	//TODO: Implement.
	return NULL;
}

sqlite3* SQLiteDatabase::GetDB()
{
	return db;
};

bool SQLiteDatabase::Fetch()
{
    //TODO: Recheck (Quickly fixed)
	//int nc = 0;
	//int rc = sqlite3_step(pVm, &nc, &pazValue, &pazColName);

	int rc = sqlite3_step(pVm);

	if (rc == SQLITE_ROW) return true;
	else
	{
		QueryClose();
		return false;
	}
}

bool SQLiteDatabase::QueryClose()
{
    if (! pVm) return true;

	lastErr = "";

	//Removed from 3x versions of SQLite.
	//char *pzErrMsg = NULL;

	int rc = sqlite3_finalize(pVm);
	if (rc != SQLITE_OK)
	{
		lastErr = GetErrorMessage(rc);
	}

	pVm = NULL;

	return rc == SQLITE_OK;
}

bool SQLiteDatabase::Execute(string sqlstr,...)
{
    QueryClose();
    lastErr = "";

    va_list args;
	va_start(args, sqlstr.c_str());

    const char *pzTail = NULL;  /* OUT: Part of zSQL not compiled */

	//Excluded from version 3x
	//char *pzErrMsg = NULL;

	char *sql = sqlite3_vmprintf(sqlstr.c_str(), args);

	//TODO: Check for utf16 support, sizeof functionality, pVm etc.
	int rc = sqlite3_prepare(db, sql, sizeof(*sql), &pVm, &pzTail);
	sqlite3_free(sql);
	va_end(args);


	if (rc != SQLITE_OK)
	{
		lastErr = GetErrorMessage(rc);
	}
	else
	{
		Fetch();
	};

	return lastErr == "";
}

bool  SQLiteDatabase::ResultExecute(const string sql, ...)
{
    sqlite3_free_table(result);
	lastErr = "";
	char *errmsg = NULL;
	ncolumn = 0;
	nrow = 0;

	//va_list args;

	//va_start(args, sql);
	int rc = SQLITE_ERROR;
    //const char* pChar = "CREATE TABLE t1 (a,b)" ;

    rc = sqlite3_get_table(db, sql.c_str(), &result, &nrow, &ncolumn, &errmsg);
    //rc = sqlite3_get_table(db, "CREATE TABLE t1 (a,b)", &result, &nrow, &ncolumn, &errmsg);
    //rc = sqlite3_get_table(db, pChar, &result, &nrow, &ncolumn, &errmsg);

	//va_end(args);

	if (rc != SQLITE_OK)
	{
		if (errmsg)
		{
			lastErr = string(errmsg);
        }

		return false;
	}

	return true;
}

bool SQLiteDatabase::eof() const
{
    return pVm == NULL;
}

int SQLiteDatabase::NumFields() const
{
    return ncolumn;
}

int SQLiteDatabase::NumChanges()
{
    return sqlite3_changes(db);//Changed to 3x version. (3)
}

int SQLiteDatabase::LastID()
{
    return sqlite3_last_insert_rowid(db);
}

string SQLiteDatabase::GetDBName()
{
    return dbName;
}

int SQLiteDatabase::GetNumRows()
{
    return nrow;
}

int SQLiteDatabase::GetNumCols()
{
    return ncolumn;
}

string SQLiteDatabase::GetColumnName(int colIdx)
{
    assert(colIdx >= 0 && colIdx < ncolumn);
    return string(result[colIdx]);
}

string SQLiteDatabase::GetFieldName(int fieldIdx)
{
	assert(fieldIdx >= 0 && fieldIdx < ncolumn);
	assert(result != NULL);

	return string(result[fieldIdx]);
}

string SQLiteDatabase::GetField(int rowIdx, int colIdx) // 0 based id
{
	assert(colIdx >= 0 && colIdx < ncolumn);
	assert(result != NULL);
	assert(rowIdx >= 0 && rowIdx < nrow);

	return string(result[(rowIdx + 1) * ncolumn + colIdx]);
}
