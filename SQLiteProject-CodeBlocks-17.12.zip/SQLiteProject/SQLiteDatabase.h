/* *************************************************************************************
*************** This is a modified version of SQLite v 3.24 Wrapper ***************************
******************** Original source codes from ****************************************
**************** SQLite Control Center of Sourceforge **********************************
*************** Modified by Muhammad Sayed Aktar Rahman ********************************
*************************   29th Aug 2018 **********************************************
******************   GNU GENERAL PUBLIC LICENSE   **************************************
******************       Version 2, June 1991    ***************************************
****************************************************************************************
*********   Copyright (C) 1989, 1991 Free Software Foundation, Inc.   ******************
*********   51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA    ******************
*/

#ifndef SQLITEDATABASE_H
#define SQLITEDATABASE_H
#include <string>
#include <map>
#include "sqlite3.h"
#include <stddef.h>
#include<iostream>

using namespace std;

class SQLiteDatabase
{
    public:
        string lastErr;

        SQLiteDatabase();
        SQLiteDatabase(string filename);
        virtual ~SQLiteDatabase();

        bool Open(string filename);
        bool Close();

        bool Ok() const {return db != NULL;};

        string SQLiteVersion();
        sqlite3* GetDB();

        bool Fetch();
        bool QueryClose();
        bool Execute(string sqlstr,...);
        bool ResultExecute(const string sql, ...);

        bool eof() const;

        int NumFields() const;
        int NumChanges();
        int LastID();
        int GetNumRows();
        int GetNumCols();

        string GetDBName();
        string GetColumnName(int colIdx);
        string GetFieldName(int fieldIdx);
        string GetField(int rowIdx, int colIdx);

    protected:

    private:
        string          dbName;

        sqlite3         *db;
        sqlite3_stmt    *pVm;

        char            **result;
        int             nrow;
        int             ncolumn;

        string GetErrorMessage(int errorCode);
};

#endif // SQLITEDATABASE_H
