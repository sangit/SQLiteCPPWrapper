#include <iostream>
#include "SQLiteDatabase.h"
#include <stddef.h>
#include<string>
#include <stdio.h>

using namespace std;

int callback(void *NotUsed, int argc, char **argv,
                    char **azColName) {

    NotUsed = 0;

    for (int i = 0; i < argc; i++) {

        printf("%s = %s\n", azColName[i], argv[i] ? argv[i] : "NULL");
    }

    printf("\n");

    return 0;
}

int main()
{
    /* **********  C test code from web ***************/

    char *err_msg = 0;
    sqlite3 *db_;

    int rc = sqlite3_open("test.db", &db_);
    if (rc != SQLITE_OK) {

        fprintf(stderr, "Cannot open database: %s\n", sqlite3_errmsg(db_));
        sqlite3_close(db_);

        return 1;
    }



    char* sql_ =   "DROP TABLE IF EXISTS Cars;"
            "CREATE TABLE Cars(Id INT, Name TEXT, Price INT);"
            "INSERT INTO Cars VALUES(1, 'Audi', 52642);"
            "INSERT INTO Cars VALUES(2, 'Mercedes', 57127);"
            "INSERT INTO Cars VALUES(3, 'Skoda', 9000);"
            "INSERT INTO Cars VALUES(4, 'Volvo', 29000);"
            "INSERT INTO Cars VALUES(5, 'Bentley', 350000);"
            "INSERT INTO Cars VALUES(6, 'Citroen', 21000);"
            "INSERT INTO Cars VALUES(7, 'Hummer', 41400);"
            "INSERT INTO Cars VALUES(8, 'Volkswagen', 21600);";


    rc = sqlite3_exec(db_, sql_, 0, 0, &err_msg);

    if (rc != SQLITE_OK ) {

        fprintf(stderr, "SQL error: %s\n", err_msg);

        sqlite3_free(err_msg);
        sqlite3_close(db_);

        return 1;
    }

    int last_id = sqlite3_last_insert_rowid(db_);
    printf("The last Id of the inserted row is %d\n", last_id);


    sql_ = "SELECT * FROM Cars";

    rc = sqlite3_exec(db_, sql_, callback, 0, &err_msg);

    if (rc != SQLITE_OK ) {

        fprintf(stderr, "Failed to select data\n");
        fprintf(stderr, "SQL error: %s\n", err_msg);

        sqlite3_free(err_msg);
        sqlite3_close(db_);

        return 1;
    }

    sql_ = "";
    sqlite3_close(db_);


    //*********** C++ Wrapper test codes  *******************

    SQLiteDatabase db;
    string sql;

    db.Open("mydb.db");

    cout << "New Database created : "<< db.GetDBName() << endl;
    cout<<endl;

    sql =   "DROP TABLE IF EXISTS Cars;"
            "CREATE TABLE Cars(Id INT, Name TEXT, Price INT);"
            "INSERT INTO Cars VALUES(1, 'Audi', 52642);"
            "INSERT INTO Cars VALUES(2, 'M.cedes', 57127);"
            "INSERT INTO Cars VALUES(3, 'Skoda', 9000);"
            "INSERT INTO Cars VALUES(4, 'Volvo', 29000);"
            "INSERT INTO Cars VALUES(5, 'Bentley', 350000);"
            "INSERT INTO Cars VALUES(6, 'Citroen', 21000);"
            "INSERT INTO Cars VALUES(7, 'Hummer', 41400);"
            "INSERT INTO Cars VALUES(8, 'V.Wagen', 21600);";

    db.ResultExecute(sql);

    cout<<"After Create Table and Insert statements."<<endl;
    cout<<"Number of columns = " <<db.GetNumCols()<<endl;   // Create table or insert donot return number of columns or rows or result
    cout<<"Number of rows = " <<db.GetNumRows()<<endl;      // Create table or insert donot return number of columns or rows or result
    cout<<endl;

    sql = "SELECT * FROM Cars";
    db.ResultExecute(sql);
    cout<<"After Select statement."<<endl;
    cout<<"Number of columns = " <<db.GetNumCols()<<endl;
    cout<<"Number of rows = " <<db.GetNumRows()<<endl;
    cout<<endl;

    for(int i = 0 ;i< db.GetNumCols();i++)cout << db.GetColumnName(i)<<"\t\t";
    cout<<endl;

    for(int j=0; j < db.GetNumRows(); j++)
    {
        for(int i = 0 ; i< db.GetNumCols(); i++)
        {
            cout << db.GetField(j,i)<<"\t\t";
        }

        cout<<endl;
    }

    if(db.Ok())db.Close();

    return 0;
}
